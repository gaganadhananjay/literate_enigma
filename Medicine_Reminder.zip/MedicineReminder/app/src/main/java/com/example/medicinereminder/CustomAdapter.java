package com.example.medicinereminder;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import static androidx.core.content.ContextCompat.startActivity;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList med_name, med_dosage,med_time;

    CustomAdapter(Activity activity, Context context, ArrayList med_name, ArrayList med_dosage,ArrayList med_time){
        this.activity = activity;
        this.context = context;
        this.med_name = med_name;
        this.med_dosage = med_dosage;
        this.med_time=med_time;

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.med_name_txt1.setText(String.valueOf(med_name.get(position)));
        holder.med_dos_txt1.setText(String.valueOf(med_dosage.get(position)));
        holder.med_time_txt1.setText(String.valueOf(med_time.get(position)));
        holder.bset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context,MainActivity3.class));
            }
        });
        holder.bcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"alarm cancelled",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return med_name.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView med_name_txt1, med_dos_txt1,med_time_txt1;
        Button bset,bcancel;
        LinearLayout mainLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            med_name_txt1 = itemView.findViewById(R.id.med_name_txt);
            med_dos_txt1 = itemView.findViewById(R.id.med_dos_txt);
            med_time_txt1 = itemView.findViewById(R.id.med_time_txt);
            bset= itemView.findViewById(R.id.bset);
            bcancel= itemView.findViewById(R.id.bcancel);


            mainLayout = itemView.findViewById(R.id.mainLayout);
            //Animate Recyclerview

        }
    }

}
