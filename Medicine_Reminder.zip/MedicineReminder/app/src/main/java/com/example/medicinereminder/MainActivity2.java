package com.example.medicinereminder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private Button submit;
    private EditText medName,medDose,medDate,medDay;
    private DBHandler dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        medName=(EditText)findViewById(R.id.mName);
        medDose=findViewById(R.id.mDose);
        medDate=findViewById(R.id.mDate);
        medDay=findViewById(R.id.mDay);
        submit=findViewById(R.id.bSubmit);
        dbHandler = new DBHandler(MainActivity2.this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mediName = medName.getText().toString();
                String mediDose = medDose.getText().toString();
                String mediDate = medDate.getText().toString();
                String mediDay = medDay.getText().toString();

                // validating if the text fields are empty or not.
                if (mediName.isEmpty() && mediDose.isEmpty() && mediDate.isEmpty() && mediDay.isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }


                boolean r=dbHandler.addNewMedicine(mediName, mediDose, mediDate, mediDay);

                // after adding the data we are displaying a toast message.
                if(r==true) {
                    Toast.makeText(MainActivity2.this, "Medicine has been added.", Toast.LENGTH_SHORT).show();
                    medName.setText("");
                    medDose.setText("");
                    medDate.setText("");
                    medDay.setText("");
                    Intent it = new Intent(MainActivity2.this, MainActivity4.class);

                    startActivity(it);
                }
                else{
                    Toast.makeText(MainActivity2.this, "Medicine not added", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }
}