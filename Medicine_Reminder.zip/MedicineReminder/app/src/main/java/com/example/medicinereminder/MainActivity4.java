package com.example.medicinereminder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity {

    RecyclerView recyclerView;
    DBHandler myDB;
    ArrayList<String> med_name, med_dosage,med_time;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        myDB = new DBHandler(MainActivity4.this);
        med_name = new ArrayList<>();
        med_dosage = new ArrayList<>();
        med_time = new ArrayList<>();


        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        storeDataInArrays();

        customAdapter = new CustomAdapter(MainActivity4.this,this, med_name,med_dosage,med_time);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity4.this));
    }
    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this,"no data",Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                med_name.add(cursor.getString(1));
                med_dosage.add(cursor.getString(2));
                med_time.add(cursor.getString(4));

            }

        }
    }
}