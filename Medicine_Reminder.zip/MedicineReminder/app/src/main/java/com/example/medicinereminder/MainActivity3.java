package com.example.medicinereminder;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DialogFragment;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity3 extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {
    private Button b1,b2;
    private TextView t1;
    private EditText d1;
    int year1,day,mon1;
    private final static String default_notification_channel_id = "default";
    Date date;
    DBHandler mDB;
  String d;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        t1=findViewById(R.id.textView);

        d1=findViewById(R.id.datec);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d=d1.getText().toString();
                if(d.isEmpty()){
                    Toast.makeText(MainActivity3.this,"Enter the date",Toast.LENGTH_LONG).show();
                    return;
                }
                DialogFragment timePicker=new TimePickerFragment();
                timePicker.show(getFragmentManager(),"time picker");


            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm();


            }
        });
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        d=d1.getText().toString();
        SimpleDateFormat dateFormat= new SimpleDateFormat("dd/MMM/yyyy");
        try {
            date=dateFormat.parse(d);
             day=date.getDate();
              mon1=date.getMonth();
             year1=date.getYear();

        } catch (ParseException e) {
            e.printStackTrace();
        }


        Calendar c= Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hourOfDay);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.YEAR,year1);
        c.set(Calendar.MONTH,mon1);
        c.set(Calendar.DAY_OF_MONTH,day);


        t1.setText("Hour : "+hourOfDay+" Minute : "+minute);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startAlarm(c);
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void startAlarm(Calendar c) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(),
                1000 * 60 * 20, pendingIntent);

    }
    private void cancelAlarm() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        alarmManager.cancel(pendingIntent);
        t1.setText("Alarm canceled");
    }


}