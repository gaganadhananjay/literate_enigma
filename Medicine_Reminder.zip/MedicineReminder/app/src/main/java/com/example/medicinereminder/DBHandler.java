package com.example.medicinereminder;

import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;


public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME = "medicine.db";


    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "medicineList";

    // below variable is for our id column.
    private static final String ID_COL = "id";


    private static final String NAME_COL = "name";


    private static final String DOSAGE_COL = "dosage";
    private static final String DATE_COL = "date";
    private static final String TIME_COL = "time";



    public DBHandler( Context context) {

        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + TABLE_NAME + " ( id INTEGER PRIMARY KEY AUTOINCREMENT, name  TEXT,dosage INTEGER,date TEXT,time TEXT)";



        db.execSQL(query);
    }
    public boolean addNewMedicine(String medicineName, String medicineDosage, String medicineDate, String medicineTime) {


        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(NAME_COL, medicineName);
        values.put(DOSAGE_COL, medicineDosage);
        values.put(DATE_COL, medicineDate);
        values.put(TIME_COL, medicineTime);

        long b=db.insert(TABLE_NAME, null, values);
        if(b==-1)
            return false;
        else
            return true;



    }
    Cursor readAllData(){
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }
}
